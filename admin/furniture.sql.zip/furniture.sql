-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jan 23, 2020 at 01:17 AM
-- Server version: 5.6.21
-- PHP Version: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `furniture`
--

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE IF NOT EXISTS `addresses` (
`address_id` int(250) NOT NULL,
  `country` varchar(250) NOT NULL,
  `city` varchar(250) NOT NULL,
  `location` varchar(250) NOT NULL,
  `street` varchar(250) NOT NULL,
  `building` varchar(250) NOT NULL,
  `customer_id` int(250) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addresses`
--

INSERT INTO `addresses` (`address_id`, `country`, `city`, `location`, `street`, `building`, `customer_id`) VALUES
(2, 'jordan', 'amman', 'hom', 'ho', 'hohoh', 1),
(3, 'jordan', 'mmm', 'hom', 'ho', 'hohoh', 1),
(4, '', '', '', '', '', 1),
(5, '', '', '', '', '', 1),
(6, '', '', '', '', '', 1),
(7, '', '', '', '', '', 1),
(8, '', '', '', '', '', 1),
(9, '', '', '', '', '', 1),
(10, 'Ø©', 'Ø©', 'Ø©', 'Ø©', 'Ø©', 1),
(11, 'Jordan', 'Amman', 'Jbeha', 'jjj', '5', 1),
(12, 'jordan', 'fg', 'asdfghj', 'sdfgh', 'ertyui', 1),
(13, '', '', '', '', '', 1),
(14, 'jordan', 'mmm', 'hom', 'mmm', 'mmm', 1),
(15, 'jordan', 'amman', 'Jbeha', 'mmm', 'ertyui', 1),
(16, '', '', '', '', '', 1),
(17, '', '', '', '', '', 1),
(18, '', '', '', '', '', 1),
(19, '', '', '', '', '', 1),
(20, '', '', '', '', '', 1),
(21, '', '', '', '', '', 1),
(22, '', '', '', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
`admin_id` int(250) NOT NULL,
  `admin_email` varchar(250) NOT NULL,
  `admin_password` varchar(250) NOT NULL,
  `fullname` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_email`, `admin_password`, `fullname`) VALUES
(1, 'basharrida@gmail.com', '123456', 'bashar akkoub'),
(2, 'salamehyassin@gmail.com', '1234', 'salameh yassin');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE IF NOT EXISTS `category` (
`cat_id` int(250) NOT NULL,
  `cat_name` varchar(250) NOT NULL,
  `cat_image` varchar(250) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_id`, `cat_name`, `cat_image`) VALUES
(2, 'sofas', 'products.jpg'),
(3, 'Tables', 'download1.jpg'),
(4, 'Bed rooms', 'bedroom.jpg'),
(5, 'Accent Chairs', 'accent-chair-9572-1.jpg'),
(6, 'Recliners', 'imagess.jpg'),
(8, 'Living Room', 'Sectionalsroomrid.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
`customer_id` int(250) NOT NULL,
  `name` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `mobile` varchar(250) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `name`, `email`, `password`, `mobile`) VALUES
(1, 'bashar akkoub', 'basharrida@gmail.com', '123456', '07878554564'),
(2, 'yazan', 'yazan@gmail.com', '123456', '0795787781'),
(3, '', 'basharrida@gmail.com', '123456', ''),
(4, '', 'basharrida@gmail.com', '123456', ''),
(5, '', 'basharrida@gmail.com', '13456', ''),
(6, '', 'basharrida@gmail.com', '123456', ''),
(7, '', 'basharrida@gmail.com', '123456', ''),
(8, 'Mohammad', 'mohammad@gmail.com', '123456', '07878910'),
(9, '', 'mohammad@gmail.com', '123456', ''),
(10, '', 'basharrida@gmail.com', '123456', ''),
(11, '', 'basharrida@gmail.com', '123456', ''),
(12, '', 'basharrida@gmail.com', '123456', ''),
(13, '', 'basharrida@gmail.com', '123456', ''),
(14, '', 'basharrida@gmail.com', '123456', ''),
(15, '', 'basharrida@gmail.com', '123456', ''),
(16, '', 'basharrida@gmail.com', '123456', ''),
(17, '', 'basharrida@gmail.com', '123456', ''),
(18, '', 'basharrida@gmail.com', '123456', '');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
`order_id` int(250) NOT NULL,
  `customer_id` int(250) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Total_paid` int(11) NOT NULL,
  `product_ids` varchar(500) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `customer_id`, `order_date`, `Total_paid`, `product_ids`) VALUES
(18, 1, '2020-01-21 01:29:16', 0, '  '),
(19, 1, '2020-01-21 08:10:12', 400, ' 1.Poundex PDEX<br> '),
(20, 1, '2020-01-21 22:20:04', 700, ' 1.Ibiza Sofa<br>2.Ibiza Sofa<br> ');

-- --------------------------------------------------------

--
-- Table structure for table `order_products`
--

CREATE TABLE IF NOT EXISTS `order_products` (
  `order_id` int(11) NOT NULL,
  `Product_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
`product_id` int(250) NOT NULL,
  `product_name` varchar(250) NOT NULL,
  `product_price` varchar(250) NOT NULL,
  `product_desc` varchar(250) NOT NULL,
  `cat_id` int(250) NOT NULL,
  `product_image` varchar(250) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`product_id`, `product_name`, `product_price`, `product_desc`, `cat_id`, `product_image`) VALUES
(2, 'Wood Martin Accent Chair', '50$', 'Sleek and refined, our Upholstered Metal and Wood Martin Accent Chair lends itself well to both modern and rustic decor styles', 5, '192841_1.jpg'),
(3, 'Tiarella Accent Chair ', '100$', 'Feel like royalty while you relax in the Tiarella accent chair. Featuring a soft and sleek ash gray upholstery, tall arms, and fancy accents', 5, 'qqqqq.gif'),
(4, 'Rug-Printed Simon Accent Chair', '200$', 'Taking cues from the intricate, overdyed motifs of traditional Berber carpets, this room-anchoring piece lends a welcoming warmth to your living', 5, '49727845_066_b10.jpg'),
(5, 'Carla Accent Chair', '150$', 'Charmed Living. With a blend of contemporary colors in this traditional, decorative accent pattern', 5, '81U1d8MssHL._SX466_.jpg'),
(6, 'Jollene Leather Accent Chair', '250$', 'The sleek lines of this retro accent chair recall futuristic, mid-century style while its sumptuous leather upholstery offers superior comfort', 5, '8358894_fpx.jpg'),
(7, 'Modern Grey Swivel Accent Chair', '300$', 'With its deep tufted back accented by rhinestone buttons and rich velvet upholstery, the Modern Grey Swivel Accent Chair adds glamorous comfort', 5, 'accent-chair-9572-1.jpg'),
(8, 'Ibiza Sofa', '350$', 'More than just the centerpiece to your living room look, sofas define your overall aesthetic and are a symbol of relaxation.', 2, 'Ibiza+Sofa.jpg'),
(9, 'Poundex PDEX', '400$', 'A chic design of fashionable flare is delivered with this 3-piece sectional sofa covered in a smooth but functional fabric. ', 2, '71wlTyhPVEL._AC_SX522_.jpg'),
(10, 'Faux Leather Chesterfield 3 Seater Sofa', '450$', 'Introducing the newest addition to our sofa range this beautiful Faux Leather Chesterfield sofa in a Blood red colour', 2, 'faux.jpg'),
(14, 'Victoria RHS Sectional Sofa in Grey & Black Colour', '123$', ' casa means "home". Muebles Casa is a new brand in the industry run by qualified', 2, 'asdf.webp'),
(15, 'Aster 3 Seater Sofa', '345$', 'The Aster 3 seater sofa provides a modern twist on traditional Scandinavian design.', 2, '7951.jpg'),
(16, 'Solid Wood Farmhouse Dining Table', '456$', 'Built and finished by hand at James+James, the Farmhouse Table exemplifies timeless, rustic American design.', 3, '91BT78gvf+L._SX425_.jpg'),
(17, 'Navarro Round Dining Table', '567$', 'Crafted by master furniture builders from American ash veneer and steel, this imposing circular table will host daily dinners', 3, 'navarro-round-dining-table-monterey-c.jpg'),
(18, 'Summer Home Elegant Round Dining Table', '456$', 'This exquisite round dining table will be a fantastic addition to your home. It features a beautiful round table top and a lovely pedestal base', 3, 'products_fine_furniture_design_color_summer home ffd_1050-810+811-b.jpg'),
(19, 'European Traditional King Mansion Bedroom', '765$', 'A bedroom fit for royalty, Dumped for half off market price! The Cordoba king suite by Pulaski is crafted with knotty oak veneers', 4, '0013155_pulaski-5-piece-cordoba-european-traditional-king-mansion-bedroom_1200.jpeg'),
(20, 'Parma bedroom', '987$', 'Bedroom set contains 200*200 bed, 2 nightstands, dresser,mirror & 4 doors waredrobe color White', 4, 'bedroom.jpg'),
(21, 'Agnes Configurable', '654$', 'Anchor your living room with this charming and chic living room set, perfect for movie nights and casual cocktail parties.', 8, 'qwer.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addresses`
--
ALTER TABLE `addresses`
 ADD PRIMARY KEY (`address_id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
 ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
 ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
 ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
 ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
 ADD PRIMARY KEY (`product_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addresses`
--
ALTER TABLE `addresses`
MODIFY `address_id` int(250) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
MODIFY `admin_id` int(250) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
MODIFY `cat_id` int(250) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
MODIFY `customer_id` int(250) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
MODIFY `order_id` int(250) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
MODIFY `product_id` int(250) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
